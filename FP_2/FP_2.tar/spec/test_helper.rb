require 'simplecov'

SimpleCov.start